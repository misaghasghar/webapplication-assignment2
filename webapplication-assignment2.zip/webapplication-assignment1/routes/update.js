var express = require('express');
var router = express.Router();
const contacts = require('../models/contacts');
/* GET update. */
router.get('/', function(req, res, next) {
  res.render('update', { title: 'update page',
  contacts: contacts
});
});
module.exports = router;

var express = require('express');
const contacts = require('../models/contacts');
var router = express.Router();
const user = require('../user.json');
// /* GET login. */
router.get('/', function(req, res, next) {
  res.render('login', { title: 'Login Page' });
});
router.post('/', function(req, res, next) {
  if(user.username=== req.body.username && user.password===req.body.password){
    res.render('contactlist', {title: 'logged in!'});   
  }
  else{
    res.redirect('login');
    
  } 
});
module.exports = router;
var express = require('express');
var router = express.Router();
const contacts = require('../models/contacts');
/* GET contact list. */


router.get('/',(req, res, next) => {
  // to load all the contacts 
  contacts.find( (err, contacts) => {
    if (err) {
      return console.error(err);
    }
    else {
      res.render('contactlist', {
        title: 'contacts',
        contacts:contacts
      });
    }
  });

});

//passing the information from the update page and updating the database
router.post('/:id', (req, res, next) => {
  let id = req.params.id;
  let updateContact = contacts({
    "_id": id,
    "Name": req.body.Name,
    "Phone": req.body.Phone,
    "Email": req.body.Email,
  });

  contacts.updateOne({_id: id}, updateContact, (err)=>{
    if (err) {
      return console.error(err);
    }
    else {
      res.redirect('/contaclist');
    }
  });
});

//This function is used to delete a contact
router.get('/delete/:id', (req, res, next) => {
  let id = req.params.id;
  book.remove({_id:id},(err)=>{
    if (err) {
      return console.error(err);
    }
    else {
      res.redirect('/contactlist');
    }
  });
});


module.exports = router;

module.exports = {
    //URI for database
    "URI": "mongodb+srv://misaghasghari:Jordanagh2244@bookdb.hhahnv3.mongodb.net/?retryWrites=true&w=majority"
  };
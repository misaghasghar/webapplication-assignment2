let mongoose = require('mongoose');

let Contact = mongoose.Schema({
    Name: String,
    Phone: String,
    Email: String 
},{
collection: 'contacts'
});
module.exports = mongoose.model('Contact', Contact);